# CPSC 250L Lab 3 Grader

This is a first-pass automated grader for Lab 3's `temperature_report.py`.

It checks:

- clone/update
- `temperature_report.py` exists
- `june_temperatures.txt` or similar data file exists
- program uses functions
- expected functions exist
- comments/docstrings exist
- file-reading behavior works
- average/min/max/count-above-threshold calculations are correct
- program runs from the terminal
- output looks readable
- meaningful Git commit evidence exists
- working tree is clean

The Lab 3 checkoff includes "Program runs successfully in PyCharm"; that remains manual.

## students.csv

```csv
name,github_username,repo_url,type
Edward Test,edwardbrash,https://github.com/edwardbrash/cpsc250L.git,test
Alice Smith,asmith,https://github.com/asmith/cpsc250L.git,student
Bob Jones,bjones,https://github.com/bjones/cpsc250L.git,student
```

The `type` column is optional.

## Run

```bash
python grade_lab03.py \
  --students students.csv \
  --workdir student_repos \
  --report reports/lab03_report.csv
```

## Exclude test account

```bash
python grade_lab03.py \
  --students students.csv \
  --workdir student_repos \
  --report reports/lab03_report.csv \
  --exclude-test
```

## With known Lab 3 starter commit

```bash
python grade_lab03.py \
  --students students.csv \
  --workdir student_repos \
  --report reports/lab03_report.csv \
  --starter-commit LAB3_STARTER_COMMIT_HASH
```

## Scoring

Automated score is out of 14.

Manual columns remain for:

- PyCharm run out of 2
- manual review out of 4

Total possible score is therefore 20.

## Important implementation detail

The sample correct solution calls `main()` directly at the bottom of the file.
For that reason, this grader does not import the whole file normally. It loads only
imports and function definitions for function-level testing, so top-level `main()`
does not run during import.
